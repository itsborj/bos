---
id: marketing.channel.gmail_auth.email.send
name: gmail-auth-email-send
description: Send an email through an authenticated Gmail social connection.
scope: execution
status: active
version: 1.0.0
allowed_from_chat: true
requires_intent:
  - execution
triggers:
  - gmail send email
  - send email through gmail
  - send mail with gmail
  - authenticated gmail send
  - gmail auth send email
excluded_triggers:
  - draft gmail outreach
  - write email copy only
  - create email content without sending
memory_slots:
  - brand_profile
  - campaign_brand_kit
related_modules:
  - marketing.channel.gmail_auth.email.send
quality_gates:
  - gmail_send_fields_present
  - gmail_oauth_token_present
metadata:
  version: 1.0.0
  author: klaroha
  plugin_id: channel.gmail_auth
---

## Activation

Activate this skill when the user wants Klaroha to send an email through Gmail using the brand's authenticated Gmail social connection.

## Do not activate

Do not activate this skill for copywriting-only requests, draft-only requests, or non-Gmail channels.

## Output contract

The module returns a `gmail_send_result` block with `status`, Gmail `message_id`, Gmail `thread_id`, recipients, and subject. Failures return a `reason_code` and diagnostic details without raising exceptions.
