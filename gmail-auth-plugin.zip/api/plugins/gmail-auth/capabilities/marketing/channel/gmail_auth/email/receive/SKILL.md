---
id: marketing.channel.gmail_auth.email.receive
name: gmail-auth-email-receive
description: Retrieve Gmail messages through an authenticated Gmail social connection.
scope: execution
status: active
version: 1.0.0
allowed_from_chat: true
requires_intent:
  - execution
triggers:
  - gmail receive emails
  - read gmail inbox
  - search gmail messages
  - get gmail emails
  - authenticated gmail receive
excluded_triggers:
  - write email copy
  - draft gmail outreach
  - summarize pasted emails
memory_slots:
  - brand_profile
  - campaign_brand_kit
related_modules:
  - marketing.channel.gmail_auth.email.receive
quality_gates:
  - gmail_receive_query_valid
  - gmail_oauth_token_present
metadata:
  version: 1.0.0
  author: klaroha
  plugin_id: channel.gmail_auth
---

## Activation

Activate this skill when the user wants Klaroha to list, search, or retrieve emails from Gmail using the brand's authenticated Gmail social connection.

## Do not activate

Do not activate this skill when the user only provides pasted email text, asks for email copywriting, or asks for a non-Gmail mailbox.

## Output contract

The module returns a `gmail_receive_result` block with `emails`, `result_size_estimate`, `next_page_token`, and the query metadata. Each email contains Gmail IDs, headers, labels, snippet, and optionally a decoded text body.
