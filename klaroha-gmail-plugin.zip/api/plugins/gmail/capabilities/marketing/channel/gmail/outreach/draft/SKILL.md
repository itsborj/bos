---
id: marketing.channel.gmail.outreach.draft
name: gmail-outreach-draft
description: Use when the CMO asks to write, draft, generate, or create an outreach email, cold email, or introduction email via Gmail. Activates on: write an email, draft an outreach, gmail outreach, send an email to, cold email for. For email sequences (multi-step drip), use the email-sequence skill instead. For internal client onboarding emails, defer to the workspace CMO context skill.
scope: execution
status: active
version: 0.1.0
allowed_from_chat: true
requires_intent:
  - generation
triggers:
  - gmail
  - write an email
  - draft an email
  - outreach email
  - cold email
  - email to
excluded_triggers:
  - email sequence
  - drip campaign
  - newsletter
memory_slots:
  - brand_profile
  - campaign_brand_kit
related_modules:
  - marketing.channel.gmail.outreach.draft
quality_gates:
  - subject_line_present
  - content_within_char_limit
  - no_banned_phrases
metadata:
  version: 0.1.0
  author: third-party
  plugin_id: channel.gmail
---

## Gmail Outreach Draft

Generates a single cold outreach email (subject + body) on behalf of a brand.

### When to activate
- CMO asks to write or draft an outreach email, introduction email, or cold email
- CMO mentions "gmail" as the channel
- CMO asks to "send an email" to a specific audience or lead

### Do not activate for
- Multi-step email sequences → use email-sequence skill
- Newsletter campaigns → not implemented in this plugin version
- Internal operational emails

### Output contract
Every output must contain exactly:
1. `Subject:` line on the first line (max 60 chars)
2. `---` separator
3. Body (3–5 paragraphs, max 400 words)
4. Clear call-to-action
5. Sign-off

### Quality gates
- `subject_line_present` — output must start with `Subject:`
- `content_within_char_limit` — total content under 4000 chars
- `no_banned_phrases` — "guaranteed", "100% free", "act now" are blocked
